namespace Ksql.EntityFramework.Models;

public enum ChangeType
{
   Insert,
   Update,
   Delete
}