namespace Ksql.EntityFramework.Models;

public enum ValueFormat
{
   Avro,
   Json,
   Protobuf,
   Csv,
   Delimited
}