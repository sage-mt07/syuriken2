namespace Ksql.EntityFramework.Models;

public enum JoinType
{
   Inner,
   Left,
   FullOuter
}